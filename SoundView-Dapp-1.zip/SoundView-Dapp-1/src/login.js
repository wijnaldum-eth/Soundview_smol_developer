```javascript
document.addEventListener('DOMContentLoaded', (event) => {
    const loginForm = document.getElementById('login-form');
    const usernameInput = document.getElementById('username-input');
    const passwordInput = document.getElementById('password-input');
    const submitButton = document.getElementById('submit-button');

    loginForm.addEventListener('submit', (event) => {
        event.preventDefault();
        submitForm();
    });

    function validateInput() {
        if (usernameInput.value === '' || passwordInput.value === '') {
            alert('Please fill in all fields');
            return false;
        }
        return true;
    }

    function submitForm() {
        if (!validateInput()) {
            return;
        }
        handleLogin(usernameInput.value, passwordInput.value);
    }

    function handleLogin(username, password) {
        fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: username,
                password: password,
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = '/dashboard';
            } else {
                alert('Invalid credentials');
            }
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }
});
```