import os

# Database configuration
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///database.db')

# Secret key for session management
SECRET_KEY = os.getenv('SECRET_KEY', 'secret-key')

# Othent Wallet SDK configuration
SDK_CONFIG = {
    'api_key': os.getenv('OTHENT_API_KEY', 'default-api-key'),
    'api_secret': os.getenv('OTHENT_API_SECRET', 'default-api-secret'),
    'redirect_url': os.getenv('OTHENT_REDIRECT_URL', 'http://localhost:5000/callback')
}