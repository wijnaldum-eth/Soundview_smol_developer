import sqlite3
from sqlite3 import Error
from user import UserSchema
from session import SessionSchema

def create_connection():
    conn = None;
    try:
        conn = sqlite3.connect(':memory:') # creates a database in RAM
        print(sqlite3.version)
    except Error as e:
        print(e)
    return conn

def create_table(conn, create_table_sql):
    try:
        c = conn.cursor()
        c.execute(create_table_sql)
    except Error as e:
        print(e)

def main():
    database = r"C:\sqlite\db\pythonsqlite.db"

    sql_create_users_table = """ CREATE TABLE IF NOT EXISTS users (
                                        id integer PRIMARY KEY,
                                        username text NOT NULL,
                                        password text NOT NULL,
                                        email text NOT NULL
                                    ); """

    sql_create_sessions_table = """CREATE TABLE IF NOT EXISTS sessions (
                                    id integer PRIMARY KEY,
                                    user_id integer NOT NULL,
                                    token text NOT NULL,
                                    FOREIGN KEY (user_id) REFERENCES users (id)
                                );"""

    conn = create_connection(database)

    if conn is not None:
        create_table(conn, sql_create_users_table)
        create_table(conn, sql_create_sessions_table)
    else:
        print("Error! cannot create the database connection.")

if __name__ == '__main__':
    main()