```python
import requests
from src.config import SDK_CONFIG

class OthentWalletSDK:
    def __init__(self):
        self.base_url = SDK_CONFIG['BASE_URL']
        self.api_key = SDK_CONFIG['API_KEY']

    def initializeSDK(self):
        response = requests.get(f'{self.base_url}/initialize', headers={'Authorization': self.api_key})
        if response.status_code == 200:
            return 'SDKInitialized'
        else:
            return 'InitializationFailed'

    def authenticateUser(self, username, password):
        payload = {'username': username, 'password': password}
        response = requests.post(f'{self.base_url}/authenticate', headers={'Authorization': self.api_key}, json=payload)
        if response.status_code == 200:
            return 'UserAuthenticated', response.json()['token']
        else:
            return 'AuthenticationFailed'

    def handleTransaction(self, token, transaction_details):
        headers = {'Authorization': self.api_key, 'Token': token}
        response = requests.post(f'{self.base_url}/transaction', headers=headers, json=transaction_details)
        if response.status_code == 200:
            return 'TransactionHandled'
        else:
            return 'TransactionFailed'
```