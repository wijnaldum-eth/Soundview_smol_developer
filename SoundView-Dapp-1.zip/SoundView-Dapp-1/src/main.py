```python
from flask import Flask, render_template, request, redirect, url_for
from src.database import Database
from src.user import User
from src.session import Session
from src.utils import hashPassword, checkPassword, generateToken
from src.othent_wallet_sdk import OthentWalletSDK
import src.config as config

app = Flask(__name__)
app.config['SECRET_KEY'] = config.SECRET_KEY

database = Database(config.DATABASE_URL)
othent_sdk = OthentWalletSDK(config.SDK_CONFIG)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.get_user(database, username)
        if user and checkPassword(password, user.password):
            session = Session.create_session(database, user.id)
            othent_sdk.authenticateUser(user.id)
            return redirect(url_for('wallet', token=session.token))
        else:
            return render_template('login.html', error='Invalid username or password')
    else:
        return render_template('login.html')

@app.route('/wallet')
def wallet():
    token = request.args.get('token')
    session = Session.get_session(database, token)
    if session:
        return render_template('wallet.html', user=session.user)
    else:
        return redirect(url_for('login'))

if __name__ == '__main__':
    othent_sdk.initializeSDK()
    app.run(debug=True)
```