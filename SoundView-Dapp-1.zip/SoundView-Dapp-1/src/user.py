```python
from src.database import UserSchema
from src.utils import hashPassword, checkPassword

class User:
    def __init__(self, username, password):
        self.username = username
        self.password = hashPassword(password)

    def createUser(self, username, password):
        user = UserSchema(username=username, password=hashPassword(password))
        user.save()

    def getUser(self, username):
        user = UserSchema.objects.get(username=username)
        return user

    def updateUser(self, username, new_password):
        user = UserSchema.objects.get(username=username)
        user.update(password=hashPassword(new_password))

    def authenticateUser(self, username, password):
        user = self.getUser(username)
        if user and checkPassword(password, user.password):
            return True
        return False
```